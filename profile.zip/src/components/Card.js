import { Box, Spacer, Link, Heading, HStack, Image, Text, VStack } from "@chakra-ui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <Box bg="white" borderRadius="lg" height="100%">
        <Image src={imageSrc} alt={title} borderRadius="lg"/>
        <VStack align="start" flex="1" p={4}>
            <Heading color="black" fontSize="sm"> {title} </Heading>
            <Text color="gray" fontSize="xs"> {description} </Text>
          <Spacer />
          <Link color="black" href="#" fontSize="xs" >
            See more <FontAwesomeIcon icon={faArrowRight} size="1x" />
          </Link>
        </VStack>
    </Box>
  );
};

export default Card;
